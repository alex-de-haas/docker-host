const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const base='/private/tmp/hosty-core-source-agent-20261014/agent-data/';
const f=JSON.parse(fs.readFileSync(base+'fixture.json')),l=JSON.parse(fs.readFileSync(base+'lifecycle-private.json'));
const report={startedAt:new Date().toISOString(),pageErrors:[],steps:[]};
const save=()=>fs.writeFileSync(path.join(f.evidenceDirectory,'source-browser-report.json'),JSON.stringify(report,null,2));
(async()=>{
const browser=await require(f.playwrightModule).chromium.connect(f.browserWebSocket),context=await browser.newContext(),page=await context.newPage();
page.on('pageerror',e=>{report.pageErrors.push(e.message.replace(/https?:\/\/\S+/g,'[url]'));save();});
try{
await page.goto(l.previewUrl+'/login');
await page.getByLabel('Email',{exact:true}).fill(f.testAccount.email);
await page.getByLabel('Password',{exact:true}).fill(f.testAccount.password);
await page.getByRole('button',{name:'Sign in',exact:true}).click();
await page.getByText('Signed in. This host has no web UI installed.',{exact:true}).waitFor({timeout:60000});
report.steps.push('normal-password-login');
const discovery=await page.evaluate(async()=>{const r=await fetch('/api/apps',{credentials:'include'}),j=await r.json(),a=j.apps.find(a=>a.id==='com.haas.demo-app');return {status:r.status,id:a.id,embeddedUrl:a.embeddedUrl,health:a.health,selectedRuntime:a.selectedRuntime,autostart:a.autostart,sourceLivePath:a.sourceLivePath};});
assert.equal(discovery.status,200);assert.equal(discovery.health.status,'healthy');assert.equal(discovery.health.services.length,2);assert(discovery.health.services.every(s=>s.health==='healthy'));assert.equal(discovery.autostart,false);report.discovery=discovery;save();
await page.goto(discovery.embeddedUrl);
await page.getByRole('heading',{name:'Hosty Demo App — Source Core verified',exact:true}).waitFor({timeout:120000});
await page.getByText('core-source-20261014',{exact:true}).waitFor({timeout:60000});
await page.getByText(f.testAccount.displayName,{exact:true}).first().waitFor({timeout:60000});
report.steps.push('source-heading-core-marker-child-user-visible');
report.locators=await page.locator('h1,h2,nav a').allTextContents();
const apis=await page.evaluate(async()=>{const out={};for(const p of ['/api/people','/api/auth/identity']){const r=await fetch(p,{credentials:'include',cache:'no-store'}),b=await r.json();out[p]={status:r.status,marker:b.directory?.coreBuildMarker,directoryStatus:b.directory?.status,user:b.appSession?{status:b.appSession.status,displayName:b.appSession.displayName,email:b.appSession.email,hostRole:b.appSession.hostRole}:undefined,people:b.people?.map(u=>({displayName:u.displayName,email:u.email,hostRole:u.hostRole}))};}return out;});
report.apis=apis;save();console.log(JSON.stringify(apis));
assert.equal(apis['/api/people'].status,200);assert.equal(apis['/api/people'].marker,'core-source-20261014');assert.equal(apis['/api/auth/identity'].status,200);assert.equal(apis['/api/auth/identity'].user.status,'active');assert.equal(apis['/api/auth/identity'].user.email,f.testAccount.email);
await page.screenshot({path:path.join(f.evidenceDirectory,'source-verified.png'),fullPage:true});
await page.getByRole('link',{name:'People',exact:true}).click();
await page.getByRole('heading',{name:'People',exact:true}).waitFor({timeout:60000});
await page.getByRole('link',{name:'Overview',exact:true}).click();
await page.getByRole('heading',{name:'Hosty Demo App — Source Core verified',exact:true}).waitFor({timeout:60000});
report.steps.push('people-and-back');save();console.log('READY_FOR_HMR');
await page.getByRole('heading',{name:'Hosty Demo App — Source Core hot reload verified',exact:true}).waitFor({timeout:240000});
await page.getByText('core-source-20261014',{exact:true}).waitFor();
await page.getByText(f.testAccount.displayName,{exact:true}).first().waitFor();
await page.screenshot({path:path.join(f.evidenceDirectory,'source-hot-reload.png'),fullPage:true});
report.steps.push('same-open-page-hmr-marker-and-user-preserved');assert.equal(report.pageErrors.length,0);report.success=true;console.log('HMR_OK');
}catch(e){report.success=false;report.failure=e.message.replace(/https?:\/\/\S+/g,'[url]');console.log(JSON.stringify({failure:report.failure}));process.exitCode=1;}
finally{report.finishedAt=new Date().toISOString();save();await context.close();await browser.close();}
})().catch(e=>{console.error(e.message);process.exit(1)});
